import React from 'react';

function AboutUs() {
return (
    <div>
        <h1>Halaman About Us</h1>
    </div>
);
}

export default AboutUs;