import React from 'react';

function Hero() {
    return (
        <div className="hero">
        <h1>Halaman Home</h1>
    </div>
    );
}

export default Hero;