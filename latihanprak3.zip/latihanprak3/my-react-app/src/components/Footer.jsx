import React from 'react';

function Footer() {
    return (
        <footer>
        <h1>Footer</h1>
    </footer>
    );
}

export default Footer;